/**
 * 
 */
/**
 * 
 */
module ContactManagerApp {
}